package com.example.dcrchecklist;


import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class DCRParser {
    private static String xmlContents;
    private static HashMap<String,DCREvent> dcrEventMap;
    public DCRParser(String xmlContents,HashMap<String,DCREvent> dcrEventMap) {
        this.xmlContents = xmlContents;
        this.dcrEventMap = dcrEventMap;
    }

    public int parse() {
        // Instantiate the Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        int lenght = 0;

        try {

            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            String xml =xmlContents.substring(1, xmlContents.length() - 1).replaceAll("\\\\\"", "\"");

            System.out.println(xml);

            Document doc =  loadXMLFromString(xml); // instead of loading from string
            doc.getDocumentElement().normalize();

            System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
            System.out.println("------");

            // get <events>

            NodeList list = doc.getElementsByTagName("event");
            lenght = list.getLength();

            for (int temp = 0; temp < list.getLength(); temp++) {

                Node node = list.item(temp);

                if (node.getNodeType() == Node.ELEMENT_NODE) {

                    Element element = (Element) node;

                    // get event's attribute
                    String id = element.getAttribute("id");
                    String label = element.getAttribute("label");
                    String description = element.getAttribute("description");
                    String included = element.getAttribute("included");
                    String pending = element.getAttribute("pending");
                    String executed = element.getAttribute("executed");


                    DCREvent event = new DCREvent(id,label,description,Boolean.parseBoolean(executed),Boolean.parseBoolean(pending),Boolean.parseBoolean(included));
                    System.out.println(event.toString());
                    dcrEventMap.put(event.getEventId(),event);

                }
            }

        } catch (ParserConfigurationException e) {
            Log.e("Parse Error: ", e.getMessage());
        } catch (SAXException e) {
            Log.e("SAX Error: ", e.getMessage());
        } catch (IOException e) {
            Log.e("IO Error: ", e.getMessage());
        }

        catch (Exception e) {
            e.printStackTrace();
        }

        return lenght;

    }



    public static Document loadXMLFromString(String xmlp)
            throws org.xml.sax.SAXException, java.io.IOException {

        return loadXMLFrom(new java.io.ByteArrayInputStream(xmlp.getBytes()));
    }

    public static Document loadXMLFrom(java.io.InputStream is)
            throws org.xml.sax.SAXException, java.io.IOException {
        javax.xml.parsers.DocumentBuilderFactory factory =
                javax.xml.parsers.DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        javax.xml.parsers.DocumentBuilder builder = null;
        try {
            builder = factory.newDocumentBuilder();
        }
        catch (javax.xml.parsers.ParserConfigurationException ex) {
        }

        org.w3c.dom.Document doc = builder.parse(is);
        is.close();
        return doc;
    }

}
