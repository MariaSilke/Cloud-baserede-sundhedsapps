package com.example.dcrchecklist;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import android.os.AsyncTask;
import android.util.Base64;

public class DCRInitializer extends AsyncTask<Void, Void, HashMap<String, String>> {
//Class establish a connection with the DCR portal, and creates a simulation on a hardcoded graph
// Change the graphId to your own graph if you do not want to use the example graph with ID 1007619
    private static final String urlBase = "https://repository.dcrgraphs.net/api/graphs/";
    private static final String graphId = "1017759";
    private String userCredentials = "";
    private String simulationId;

    public String getSimulationId() {
        return simulationId;
    }

    public void setSimulationId(String newSimulationId) {
        this.simulationId = newSimulationId;
    }

    public void setUserCredentials(String credentials) {
        this.userCredentials = credentials;
    }

    @Override
    protected HashMap<String, String> doInBackground(Void... voids) {
        try {
            HashMap<String, String> resultParams = new HashMap<String,String>();
            resultParams = sendRequest(new String(urlBase+graphId+"/sims"),"POST");

            if(resultParams != null && resultParams.get("responseCode").equals("201") ){ //simulation creation
                System.out.println("New simulation id " +getSimulationId());
            }
            resultParams.put("urlbase",urlBase);
            resultParams.put("graphId",graphId);
            return resultParams;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(HashMap<String, String> result) {
        System.out.println("Status request " + result);
    }


    private HashMap<String,String> sendRequest(String url, String typeRequest) throws IOException {
        URL obj = new URL(url);
        HashMap<String,String> result = new HashMap<>();
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setReadTimeout (10 * 1000);
        String basicAuth = "Basic " + new String(android.util.Base64.encode(userCredentials.getBytes(), Base64.DEFAULT));
        con.setRequestProperty ("Authorization", basicAuth);
        con.setRequestMethod(typeRequest);

        int responseCode = con.getResponseCode();

        System.out.println(typeRequest +" Response Code :: " + responseCode);
        switch (responseCode){
            case HttpURLConnection.HTTP_CREATED: //POST resource created, retrieve empty connection string
                setSimulationId(con.getHeaderField("X-DCR-simulation-ID"));
                break;
            default:
                System.out.println("Behavior for code "+responseCode+" not implemented");
        }
        result.put("responseCode", String.valueOf(responseCode));
        result.put("simId", getSimulationId());
        return result;
    }
}
