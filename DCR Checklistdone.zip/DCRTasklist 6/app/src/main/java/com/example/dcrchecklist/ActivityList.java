package com.example.dcrchecklist;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;


public class ActivityList extends AppCompatActivity implements OnClickListener {
LinearLayout activityList;
    HashMap<String,DCREvent> dcrEventMap = new HashMap<String, DCREvent>();
    private String simulationID;
    private String activitiesData;
    private String username;
    private String login;
    private Boolean isLoggedIn=Boolean.FALSE;
    private static final String URL = "jdbc:mysql://databasedentist.cli1nj0aggio.us-east-2.rds.amazonaws.com/DBdentist";
    private static final String USER = "adminJulie";
    private static final String PASSWORD = "Kik2julie";
    private static final String graphId = "1017759";


    @Override
    protected void onResume() {
        super.onResume();
        if (isLoggedIn) { setActivityList("");}
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new InfoAsyncTask().execute();
        login();
        setContentView(R.layout.activity_list);

        Button btnLoadDCR = (Button) findViewById(R.id.btn_loadDCREvents);
        btnLoadDCR.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Connection to DCR Active repository
                DCRInitializer connector = new DCRInitializer();
                connector.setUserCredentials(username+":"+login);
                connector.execute();
                HashMap<String,String> results = null;
                try {
                    results = connector.get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                new InsertSQL().execute();

                System.out.println("the results of the connection string are "+results);
                simulationID=results.get("simId");
                setActivityList("");


            }
        });


    }

    @SuppressLint("StaticFieldLeak")
    public class InfoAsyncTask extends AsyncTask<Void, Void, Map<String, String>> {
        @Override
        protected Map<String, String> doInBackground(Void... voids) {
            Map<String, String> info = new HashMap<>();

            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                System.out.println("succesfully connected to DB");
                String sql = "SELECT instanceID, graphID, Citizen FROM myInstances LIMIT 1";
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    info.put("instanceID", resultSet.getString("instanceID"));
                    info.put("graphID", resultSet.getString("graphID"));
                    info.put("Citizen", resultSet.getString("Citizen"));
                    simulationID=resultSet.getString("instanceID");
                    System.out.println(simulationID);
                }
            } catch (Exception e) {
                Log.e("InfoAsyncTask", "Error reading database information", e);
            }
            System.out.println("result of query:"+info);
            return info;
        }
    }

    public class InsertSQL extends AsyncTask<Void, Void, Map<String, String>> {
        @Override
        protected Map<String, String> doInBackground(Void... voids) {
            Map<String, String> info = new HashMap<>();

            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                System.out.println("succesfully connected to DB2");
                Statement stmt = connection.createStatement();
                String sql = "INSERT INTO myInstances (instanceID, graphID, Citizen) VALUES (" + simulationID + ", " + graphId + ", '" + username + "')";
                stmt.executeUpdate(sql);
                System.out.println("succesfully inserted to DB");
            } catch (Exception e) {
                Log.e("InfoAsyncTask", "Error reading database information 2", e);
            }
            return info;
        }

    }
    public class DeleteSQL extends AsyncTask<Void, Void, Map<String, String>> {
        @Override
        protected Map<String, String> doInBackground(Void... voids) {
            Map<String, String> info = new HashMap<>();

            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                System.out.println("succesfully connected to DB3");
                Statement stmt = connection.createStatement();
                String sql = "DELETE FROM myInstances WHERE instanceID = '"+simulationID+"'";
                stmt.executeUpdate(sql);
                System.out.println("succesfully deleted to DB");
            } catch (Exception e) {
                Log.e("InfoAsyncTask", "Error reading database information 3", e);
            }
            return info;
        }

    }

    public void setActivityList(String activities) {

        DCRgetevents connector = new DCRgetevents();
        connector.setSimulationId(simulationID);
        connector.setUserCredentials(username+":"+login);
        connector.execute();

        HashMap<String,String> results = null;
        try {
            results = connector.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("the results of the connection string are "+results);
        activitiesData=results.get("responseData");
        dcrEventMap.clear();
        DCRParser parser = new DCRParser(activitiesData,dcrEventMap);
        if (parser.parse()==0){
            new DeleteSQL().execute();
        }


        activityList=(LinearLayout) findViewById(R.id.layout_activities);
        activityList.removeAllViews();
        Button btn_i;
        int i = 0;
        for (Map.Entry<String, DCREvent> entry: dcrEventMap.entrySet()) {
            btn_i = new Button(ActivityList.this);
            btn_i.setId(i);
            DCREvent event = entry.getValue();
            btn_i.setText(event.getLabel());
            btn_i.setTag(entry.getKey());
            setcolor(btn_i,event);
            activityList.addView(btn_i);
            btn_i.setOnClickListener(ActivityList.this);
            i= i+1;
        }

    }

    private void setcolor(Button btn_i, DCREvent event) {
        if (event.isIncluded()){
            btn_i.setBackgroundColor(getResources().getColor(R.color.design_default_color_secondary));
        }
        else{
            btn_i.setBackgroundColor(getResources().getColor(R.color.material_on_primary_disabled));
        }
        if (event.isPending()){
            btn_i.setTextColor(getResources().getColor(R.color.design_default_color_error));
        }
        if (event.isExecuted()){
//            btn_i.setBackgroundColor(getResources().getColor(R.color.teal_200));
            btn_i.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
        }
        else{
            btn_i.setPaintFlags(btn_i.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
        }


    }

    private void startActivityInfo(DCREvent e){
    Intent startIntent = new Intent(getApplicationContext(), ActivityInfo.class);
    startIntent.putExtra("EventId",e.getEventId());
    startIntent.putExtra("label",e.getLabel());
    startIntent.putExtra("description",e.getDescription());
    startIntent.putExtra("executed",new Boolean(e.isExecuted()).toString());
    startIntent.putExtra("pending",new Boolean(e.isPending()).toString());
    startIntent.putExtra("included",new Boolean(e.isIncluded()).toString());
    startIntent.putExtra("simId",simulationID);
    startIntent.putExtra("credentials",username+":"+login);
    startActivity(startIntent);
}

    @Override
    public void onClick(View v) {
        String str = v.getTag().toString();
        DCREvent e = dcrEventMap.get(str);
        startActivityInfo(e);
    }

    public void login() {
        if (!isLoggedIn) {
            AlertDialog alert = loginDialog(this, "Provide login credentials for DCR repository");
            alert.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    if (isLoggedIn) login();
                }
            });
            alert.show();
        }
    }

    public AlertDialog loginDialog(Context c, String message) {
        LayoutInflater factory = LayoutInflater.from(c);
        final View textEntryView = factory.inflate(R.layout.login, null);
        final AlertDialog.Builder failAlert = new AlertDialog.Builder(c);
        failAlert.setTitle("Login/ Register Failed");
        failAlert.setNegativeButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Cancelled
            }
        });
        AlertDialog.Builder alert = new AlertDialog.Builder(c);
        alert.setTitle("Login to DCR repository");
        alert.setMessage(message);
        alert.setView(textEntryView);
        alert.setPositiveButton("Login", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                //try {
                    final EditText usernameInput = (EditText) textEntryView.findViewById(R.id.userNameEditText);
                    final EditText passwordInput = (EditText) textEntryView.findViewById(R.id.passwordEditText);
                    username=usernameInput.getText().toString();
                    login=passwordInput.getText().toString();
                System.out.println("username set to "+username+" and password set to "+login);
                isLoggedIn=Boolean.TRUE;
            }
        });
        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
            }
        });
        return alert.create();
    }
}