package com.example.dcrchecklist;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class ActivityInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //User code
        DCREvent currentEvent = new DCREvent();

        if(getIntent().hasExtra("EventId")){//Reference passed from previous intent
            currentEvent.updateEvent( new DCREvent(
                    getIntent().getExtras().getString("EventId"),
                    getIntent().getExtras().getString("label"),
                    getIntent().getExtras().getString("description"),
                    Boolean.parseBoolean(getIntent().getExtras().getString("executed")),
                    Boolean.parseBoolean(getIntent().getExtras().getString("pending")),
                    Boolean.parseBoolean(getIntent().getExtras().getString("included"))
            ));
            loadDCREvent(currentEvent);

        }

        Button btnExecuteEvent = (Button) findViewById(R.id.execute_button);

        btnExecuteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ///******************************* Guide for the student
                // Modify the checks so an activity is only executable if it is enabled
                // See guide in https://documentation.dcr.design/documentation/using-postman-to-access-dcr-active-repository/
                // https://repository.dcrgraphs.net/api/graphs/<graphid>/sims/<simid>//events?filter=enabled-or-pending
                ///******************************* End guide

                if (!currentEvent.isIncluded()) { //
                    AlertDialog.Builder builder = new AlertDialog.Builder(ActivityInfo.this);
                    builder.setTitle("Can't execute this activity");
                    builder.setMessage("Activity " + currentEvent.getLabel() + " is not included and therefore it cannot be executed");


                    builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    builder.show();
                } else {

                    ///******************************* Guide for the student
                    // Modify the functionality of this code so the event gets executed in the server side
                    // https://documentation.dcr.design/documentation/using-postman-to-access-dcr-active-repository/#Execute_an_event_in_a_simulation
                    // https://repository.dcrgraphs.net/api/graphs/<graphid>/sims/<simid>/events/<eventid>
                    // You will likely need to update your view in the first screen to make it consistent with the changes
                    System.out.println("We execute this event");
                    //Connection to DCR Active repository
                    //DCRexecute connector = new DCRexecute();
                    //connector.setActivityId(currentEvent.getEventId());
                    //connector.setSimulationId(getIntent().getExtras().getString("simId"));
                    //connector.execute();

                    HashMap<String,String> results = null;
                    //try {
                    //    results = connector.get();
                    //} catch (ExecutionException e) {
                    //    e.printStackTrace();
                    //} catch (InterruptedException e) {
                    //    e.printStackTrace();
                    //}
                    System.out.println("the results of the connnection string are "+results);


                }
                finish();
            }
        });

        Button btnCancelChangesEvent = (Button) findViewById(R.id.cancel_button);
        btnCancelChangesEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void loadDCREvent(DCREvent e){
        TextView eventId = (TextView) findViewById(R.id.event_id_contents);
        TextView eventLabel = (TextView) findViewById(R.id.event_label_contents);
        TextView eventDescription = (TextView) findViewById(R.id.event_description_contents);
        CheckBox chkExecuted = (CheckBox)  findViewById(R.id.executed_checkbox);
        CheckBox chkPending = (CheckBox)  findViewById(R.id.pending_checkbox);
        CheckBox chkIncluded = (CheckBox)  findViewById(R.id.included_checkbox);

        eventId.setText(e.getEventId());
        eventLabel.setText(e.getLabel());
        eventDescription.setText(e.getDescription());
        chkExecuted.setChecked(e.isExecuted());
        chkIncluded.setChecked(e.isIncluded());
        chkPending.setChecked(e.isPending());
    }

}