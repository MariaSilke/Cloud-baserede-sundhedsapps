package com.example.dcrchecklist;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import android.os.AsyncTask;
import android.util.Base64;

public class DCRInitializer extends AsyncTask<Void, Void, HashMap<String, String>> {
//Class establish a connection with the DCR portal, and creates a simulation on a hardcoded graph.
    //Change the graph and your username/password to make it functional

    private static final String urlBase = "https://repository.dcrgraphs.net/api/graphs/";
    private static final String graphId = "1007599";
    private static final String userCredentials = "juliekik@gmail.com"+":"+"Kik2julie";
    private String simulationId;
    private String eventId;

    public String getSimulationId() {
        return simulationId;
    }
    public String getEventId() { return eventId;}


    public void setSimulationId(String newSimulationId) {
        this.simulationId = newSimulationId;
    }
    public void setEventId(String newEventId) {this.eventId = newEventId; }



    @Override
    protected HashMap<String, String> doInBackground(Void... voids) {
        try {
            // Your implementation goes here

            HashMap<String, String> resultParams = new HashMap<String,String>();

            resultParams = sendRequest(new String(urlBase+graphId+"/sims"),"POST");
            if(resultParams != null && resultParams.get("responseCode").equals("201") ){ //simulation creation
                System.out.println("New simulation id " +getSimulationId());
                resultParams.clear();
                resultParams = sendRequest(new String(urlBase+graphId+"/sims/"+getSimulationId()+"//events?filter=all"),"GET");
                if(resultParams != null && resultParams.get("responseCode").equals("200") ) { //Retrieve OK, parse event collection
                    System.out.println(resultParams.get("responseData"));


                }
            }

            resultParams.put("urlbase",urlBase);
            resultParams.put("graphId",graphId);

            return resultParams;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(HashMap<String, String> result) {
        System.out.println("Status request " + result);


    }


    private HashMap<String,String> sendRequest(String url, String typeRequest) throws IOException {
        URL obj = new URL(url);
        HashMap<String,String> result = new HashMap<>();
        //StringBuffer responseResult = new StringBuffer();
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setReadTimeout (10 * 1000);
        String basicAuth = "Basic " + new String(android.util.Base64.encode(userCredentials.getBytes(), Base64.DEFAULT));
        con.setRequestProperty ("Authorization", basicAuth);
        con.setRequestMethod(typeRequest);

        int responseCode = con.getResponseCode();

        System.out.println(typeRequest +" Response Code :: " + responseCode);
        switch (responseCode){
            case HttpURLConnection.HTTP_CREATED: //POST resource created, retrieve empty connection string
                setSimulationId(con.getHeaderField("X-DCR-simulation-ID"));
                break;
           // case HttpURLConnection.HTTP_OK: //GET resource successful, retrieve data

           //     BufferedReader in = new BufferedReader(new InputStreamReader(
             //           con.getInputStream()));
            //    String inputLine;


            //    while ((inputLine = in.readLine()) != null) {
             //       responseResult.append(inputLine);
            //    }

            //    in.close();
            //    break;
            default:
                System.out.println("Behavior for code "+responseCode+" not implemented");
        }


        result.put("responseCode", String.valueOf(responseCode));
        //result.put("responseData", responseResult.toString());
        result.put("simId", getSimulationId());
        return result;
    }
}
