package com.example.dcrchecklist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;


public class ActivityList extends AppCompatActivity implements OnClickListener {
LinearLayout activityList;
    HashMap<String,DCREvent> dcrEventMap = new HashMap<String, DCREvent>();
    private String simulationID;
    private String activitiesData;

    @Override
    protected void onResume() {
// TODO Auto-generated method stub
        super.onResume();


        setActivityList("");
        //Do your code here
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        //setActivityList("");

        Button btnLoadDCR = (Button) findViewById(R.id.btn_loadDCREvents);
        btnLoadDCR.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Connection to DCR Active repository
                DCRInitializer connector = new DCRInitializer();
                connector.execute();

                HashMap<String,String> results = null;
                try {
                    results = connector.get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("the results of the connnection string are "+results);
                simulationID=results.get("simId");

                //activitiesData=results.get("responseData");
                //dcrEventMap.clear();
                //DCRParser parser = new DCRParser(activitiesData,dcrEventMap);
                //parser.parse();

                setActivityList("");
            }
        });

    }

    public void setActivityList(String activities) {


//        //Construction of Hardcoded activity list

        //DCREvent e = new DCREvent("Activity1","interview patient", "first event", false,false, true);
        //DCREvent f = new DCREvent("Activity2","take x-ray", "second event", true,false, true);
        //DCREvent g = new DCREvent("Activity3","send bill", "third event", false,true, false);
        //DCREvent h = new DCREvent("Activity4","register CPR", "fourth event", true,false, true);

        //dcrEventMap.put(e.getEventId(),e);
        //dcrEventMap.put(f.getEventId(),f);
        //dcrEventMap.put(g.getEventId(),g);
        //dcrEventMap.put(h.getEventId(),h);
        DCRgetevents connector = new DCRgetevents();
        connector.setSimulationId(simulationID);
        connector.execute();

        HashMap<String,String> results = null;
        try {
            results = connector.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("the results of the connnection string are "+results);
        activitiesData=results.get("responseData");
        dcrEventMap.clear();
        DCRParser parser = new DCRParser(activitiesData,dcrEventMap);
        parser.parse();
        

        activityList=(LinearLayout) findViewById(R.id.layout_activities);
        activityList.removeAllViews();
        Button btn_i;
        int i = 0;
        for (Map.Entry<String, DCREvent> entry: dcrEventMap.entrySet()) {
            btn_i = new Button(ActivityList.this);
            btn_i.setId(i);
            DCREvent event = entry.getValue();
            btn_i.setText(event.getLabel());
            btn_i.setTag(entry.getKey());
            setcolor(btn_i,event);
            activityList.addView(btn_i);
            btn_i.setOnClickListener(ActivityList.this);
            i= i+1;
        }

        //Construction of activity list from events extracted from a DCR graph
        // ******************* Guide for the student
        // implement the funcitonaliyt of btnLoadDCR so activityList loads the activities in the DCR graph instead of a hardcoded list of activities
        // in order to do so, you will need to visit https://documentation.dcr.design/documentation/using-postman-to-access-dcr-active-repository/
        // https://repository.dcrgraphs.net/api/graphs/<graphid>/sims/<simid>//events

    }

    private void setcolor(Button btn_i, DCREvent event) {
        if (event.isIncluded()){
            btn_i.setBackgroundColor(getResources().getColor(R.color.design_default_color_secondary));
        }
        else{
            btn_i.setBackgroundColor(getResources().getColor(R.color.material_on_primary_disabled));
        }
        if (event.isPending()){
            btn_i.setTextColor(getResources().getColor(R.color.design_default_color_error));
        }
        if (event.isExecuted()){
//            btn_i.setBackgroundColor(getResources().getColor(R.color.teal_200));
            btn_i.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
        }
        else{
            btn_i.setPaintFlags(btn_i.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
        }


    }

    private void startActivityInfo(DCREvent e){
    Intent startIntent = new Intent(getApplicationContext(), ActivityInfo.class);
    startIntent.putExtra("EventId",e.getEventId());
    startIntent.putExtra("label",e.getLabel());
    startIntent.putExtra("description",e.getDescription());
    startIntent.putExtra("executed",new Boolean(e.isExecuted()).toString());
    startIntent.putExtra("pending",new Boolean(e.isPending()).toString());
    startIntent.putExtra("included",new Boolean(e.isIncluded()).toString());
    startIntent.putExtra("simId",simulationID);
    startActivity(startIntent);
}

    @Override
    public void onClick(View v) {
        String str = v.getTag().toString();
        DCREvent e = dcrEventMap.get(str);
        startActivityInfo(e);
    }
}