package com.example.dcrchecklist;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import android.os.AsyncTask;
import android.util.Base64;

public class DCRgetevents extends AsyncTask<Void, Void, HashMap<String, String>> {
//Class establish a connection with the DCR portal and get the events for a given simulation
    //Change the graph and your username/password to make it functional

    private static final String urlBase = "https://repository.dcrgraphs.net/api/graphs/";
    private static final String graphId = "1017759";
    private String simulationId;
    private String userCredentials;
    public void setUserCredentials(String credentials) {
        this.userCredentials = credentials;
    }

    public String getSimulationId() {
        return simulationId;
    }

    public void setSimulationId(String newSimulationId) {
        this.simulationId = newSimulationId;
    }



    @Override
    protected HashMap<String, String> doInBackground(Void... voids) {
        try {
            HashMap<String, String> resultParams = new HashMap<String,String>();

            System.out.println("Trying to get events for Instance "+getSimulationId()+" of process "+graphId);
                resultParams = sendRequest(new String(urlBase+graphId+"/sims/"+getSimulationId()+"//events?filter=enabled-or-pending"),"GET");
                if(resultParams != null && resultParams.get("responseCode").equals("200") ) { //Retrieve OK, parse event collection
                    System.out.println(resultParams.get("responseData"));
                }

            resultParams.put("urlbase",urlBase);
            resultParams.put("graphId",graphId);
            return resultParams;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(HashMap<String, String> result) {
        System.out.println("Status request " + result);


    }


    private HashMap<String,String> sendRequest(String url, String typeRequest) throws IOException {
        URL obj = new URL(url);
        HashMap<String,String> result = new HashMap<>();
        StringBuffer responseResult = new StringBuffer();
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setReadTimeout (10 * 1000);
        String basicAuth = "Basic " + new String(android.util.Base64.encode(userCredentials.getBytes(), Base64.DEFAULT));
        con.setRequestProperty ("Authorization", basicAuth);
        con.setRequestMethod(typeRequest);

        int responseCode = con.getResponseCode();

        System.out.println(typeRequest +" Response Code :: " + responseCode);
        switch (responseCode){
            case HttpURLConnection.HTTP_OK: //GET resource successful, retrieve data

                BufferedReader in = new BufferedReader(new InputStreamReader(
                        con.getInputStream()));
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    responseResult.append(inputLine);
                }
                in.close();
                break;
            default:
                System.out.println("Behavior for code "+responseCode+" not implemented");
        }

        result.put("responseCode", String.valueOf(responseCode));
        result.put("responseData", responseResult.toString());
        return result;
    }
}
