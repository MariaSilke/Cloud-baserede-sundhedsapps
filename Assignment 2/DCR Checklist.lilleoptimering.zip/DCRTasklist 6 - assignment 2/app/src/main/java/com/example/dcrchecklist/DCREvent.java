package com.example.dcrchecklist;

public class DCREvent {
    private String eventId;
    private String label;
    private String description;

    private boolean executed;
    private boolean pending;
    private boolean included;

    public String getLabel() {
        return label;
    }

    public boolean isExecuted() {
        return executed;
    }

    public void setExecuted(boolean executed) {
        this.executed = executed;
    }

    public boolean isPending() {
        return pending;
    }

    public void setPending(boolean pending) {
        this.pending = pending;
    }

    public boolean isIncluded() {
        return included;
    }

    public void setIncluded(boolean included) {
        this.included = included;
    }

    public String getEventId() {
        return eventId;
    }

    public String getDescription() {
        return description;
    }

    public void updateEvent(DCREvent event){
        this.eventId = event.eventId;
        this.label = event.label;
        this.description = event.description;
        this.executed = event.executed;
        this.pending = event.pending;
        this.included = event.included;
    }

    public DCREvent(String eventId, String label, String description, boolean executed, boolean pending, boolean included) {
        this.eventId = eventId;
        this.label = label;
        this.description = description;
        this.executed = executed;
        this.pending = pending;
        this.included = included;
    }

    public DCREvent(DCREvent e) {
        this.eventId = e.getEventId();
        this.label = e.getLabel();
        this.description = e.getDescription();
        this.executed = e.isExecuted();
        this.pending = e.isPending();
        this.included = e.isIncluded();
    }

    public DCREvent(){
        this.eventId = "";
        this.label = "";
        this.description = "";
        this.executed = false;
        this.pending = false;
        this.included = false;
    }

    @Override
    public String toString() {
        return "DCREvent{" +
                "eventId='" + eventId + '\'' +
                ", label='" + label + '\'' +
                ", description='" + description + '\'' +
                ", executed=" + executed +
                ", pending=" + pending +
                ", included=" + included +
                '}';
    }
}
