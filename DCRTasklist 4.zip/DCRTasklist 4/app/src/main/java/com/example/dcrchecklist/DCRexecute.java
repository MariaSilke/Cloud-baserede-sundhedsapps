package com.example.dcrchecklist;

import android.os.AsyncTask;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

public class DCRexecute extends AsyncTask<Void, Void, HashMap<String, String>> {

    private static final String urlBase = "https://repository.dcrgraphs.net/api/graphs/";
    private static final String graphId = "1007599";
    private String simulationId;
    private static String activityId;
    public String getActivityId() {
        return activityId;
    }
    private String userCredentials;
    public void setUserCredentials(String credentials) {
        this.userCredentials = credentials;
    }

    public void setActivityId(String activityID) {
        this.activityId=activityID;
    }



    public void setSimulationId(String newSimulationId) {
       this.simulationId = newSimulationId; }

    private String getSimulationId() {
        return simulationId;
    }

    protected HashMap<String, String> doInBackground(Void... voids) {
        try {

            HashMap<String, String> resultParams = new HashMap<String, String>();
            System.out.println("Trying to execute " + getActivityId() + " in instance "+ getSimulationId());
            String request = new String(urlBase + graphId + "/sims/"+getSimulationId()+"/events/"+getActivityId()); //MISSING - write the right request URL here to execute event
            resultParams = sendRequest(request, "POST");
            if (resultParams != null && resultParams.get("responseCode").equals("204")) { //activity executed, no new content to show
                System.out.println("Executed activity " + getActivityId());
            }

            resultParams.put("urlbase", urlBase);
            resultParams.put("graphId", graphId);

            return resultParams;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(HashMap<String, String> result) {
        System.out.println("Status request " + result);


    }
    private HashMap<String,String> sendRequest(String url, String typeRequest) throws IOException {
        URL obj = new URL(url);
        HashMap<String,String> result = new HashMap<>();
        StringBuffer responseResult = new StringBuffer();
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setReadTimeout (10 * 1000);
        String basicAuth = "Basic " + new String(Base64.encode(userCredentials.getBytes(), Base64.DEFAULT));
        con.setRequestProperty ("Authorization", basicAuth);
        con.setRequestMethod(typeRequest);

        int responseCode = con.getResponseCode();

        System.out.println(typeRequest +" Response Code :: " + responseCode);
        switch (responseCode){
            case HttpURLConnection.HTTP_NO_CONTENT: //Succeeded and returned no new content
                break;
            default:
                System.out.println("Behavior for code "+responseCode+" not implemented");
        }

        result.put("responseCode", String.valueOf(responseCode));
        result.put("responseData", responseResult.toString());
        return result;
    }
}